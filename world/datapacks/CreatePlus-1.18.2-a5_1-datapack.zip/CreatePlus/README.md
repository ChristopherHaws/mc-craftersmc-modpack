# CreatePlus for Fabric/QSL Environment

A Minecraft Datapack / QuiltMod for 1.18.2 for enhancing the compatabity of [Create Farbic](https://github.com/Fabricators-of-Create/Create).

[Quilt Mod HERE](https://github.com/JieningYu/createplus-mod)

NOTE: The mod is not completed yet and it depends on this datapack.

Supported Mods:

- Tech Reborn
- Farmer's Delight
- Alloy Forgery
- Applied Energistics 2
- Betternether
- Immersive Weathering
- More Ores
- Promenade
- Unearthed
- Universal Ores
- Gobber 2
- Alloygery
- Mythic Metals
- Ecologics
- Croptopia
- Architects' Palette
- More Geodes
- The Bumblezone
- Go Fish
- Modern Industrialization
- Paradise Lost
- Blockus
- Oxidized
- Cave Enhancements
- Twigs
- Oh The Biomes You’ll Go
- Biome Makeover
